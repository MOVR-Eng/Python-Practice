from fastapi import FastAPI, UploadFile, File, Form
from fastapi.responses import HTMLResponse
from pathlib import Path
import shutil

from app.processor import main

app = FastAPI()

INBOUND_FOLDER = Path("inbound")
INBOUND_FOLDER.mkdir(exist_ok=True)


@app.get("/", response_class=HTMLResponse)
def home():

    return """
    <!DOCTYPE html>

    <html>

    <head>

        <title>EDI Processing</title>

        <style>

            body {
                font-family: Arial, sans-serif;
                margin: 40px;
                background-color: #f5f5f5;
            }

            .container {
                max-width: 800px;
                margin: auto;
            }

            h1 {
                margin-bottom: 30px;
            }

            .section {
                background: white;
                padding: 25px;
                margin-bottom: 20px;
                border-radius: 8px;
                border: 1px solid #ddd;
            }

            h2 {
                margin-top: 0;
            }

            button {
                padding: 10px 20px;
                margin-top: 15px;
                cursor: pointer;
                border: none;
                border-radius: 5px;
            }

            button:disabled {
                cursor: not-allowed;
                opacity: 0.5;
            }

            #uploadButton {
                background: #1976d2;
                color: white;
            }

            #runButton {
                background: #388e3c;
                color: white;
            }

            .status {
                margin-top: 15px;
                padding: 12px;
                border-radius: 5px;
            }

            .success {
                background: #e8f5e9;
                color: #2e7d32;
            }

            .error {
                background: #ffebee;
                color: #c62828;
            }

            .processing {
                background: #fff8e1;
                color: #f57f17;
            }

            pre {
                background: #f4f4f4;
                padding: 15px;
                border-radius: 5px;
                overflow-x: auto;
                white-space: pre-wrap;
            }

            .file-name {
                margin-top: 15px;
                font-weight: bold;
            }

        </style>

    </head>


    <body>

        <div class="container">

            <h1>EDI Processing</h1>


            <!-- Upload Section -->

            <div class="section">

                <h2>1. Upload EDI File</h2>

                <input
                    type="file"
                    id="file"
                    accept=".edi"
                >

                <br>

                <button
                    id="uploadButton"
                    onclick="uploadFile()"
                >
                    Upload EDI
                </button>

                <div id="uploadStatus"></div>

            </div>


            <!-- Processor Section -->

            <div class="section">

                <h2>2. Run Processor</h2>

                <div
                    id="selectedFile"
                    class="file-name"
                >
                    No file uploaded
                </div>

                <button
                    id="runButton"
                    onclick="runProcessor()"
                    disabled
                >
                    Run Processor
                </button>

                <div id="processorStatus"></div>

            </div>


        </div>


        <script>

            let uploadedFile = null;


            // --------------------------------
            // Upload EDI File
            // --------------------------------

            async function uploadFile() {

                const fileInput =
                    document.getElementById("file");

                const file = fileInput.files[0];


                if (!file) {

                    document.getElementById(
                        "uploadStatus"
                    ).innerHTML =
                        '<div class="status error">' +
                        '❌ Please select an EDI file.' +
                        '</div>';

                    return;
                }


                if (!file.name.toLowerCase().endsWith(".edi")) {

                    document.getElementById(
                        "uploadStatus"
                    ).innerHTML =
                        '<div class="status error">' +
                        '❌ Only .edi files are allowed.' +
                        '</div>';

                    return;
                }


                const formData = new FormData();

                formData.append("file", file);


                document.getElementById(
                    "uploadStatus"
                ).innerHTML =
                    '<div class="status processing">' +
                    '⏳ Uploading file...' +
                    '</div>';


                document.getElementById(
                    "uploadButton"
                ).disabled = true;


                try {

                    const response = await fetch(
                        "/upload",
                        {
                            method: "POST",
                            body: formData
                        }
                    );


                    const result =
                        await response.json();


                    if (result.status === "SUCCESS") {

                        uploadedFile = result.file;


                        document.getElementById(
                            "uploadStatus"
                        ).innerHTML =
                            '<div class="status success">' +
                            '✅ ' +
                            result.message +
                            '</div>';


                        document.getElementById(
                            "selectedFile"
                        ).innerHTML =
                            "Selected file: <b>" +
                            uploadedFile +
                            "</b>";


                        document.getElementById(
                            "runButton"
                        ).disabled = false;

                    }
                    else {

                        document.getElementById(
                            "uploadStatus"
                        ).innerHTML =
                            '<div class="status error">' +
                            '❌ ' +
                            result.message +
                            '</div>';

                    }

                }
                catch (error) {

                    document.getElementById(
                        "uploadStatus"
                    ).innerHTML =
                        '<div class="status error">' +
                        '❌ Upload failed: ' +
                        error +
                        '</div>';

                }
                finally {

                    document.getElementById(
                        "uploadButton"
                    ).disabled = false;

                }

            }


            // --------------------------------
            // Run EDI Processor
            // --------------------------------

            async function runProcessor() {

                if (!uploadedFile) {

                    return;

                }


                document.getElementById(
                    "processorStatus"
                ).innerHTML =
                    '<div class="status processing">' +
                    '⏳ Processing ' +
                    uploadedFile +
                    '...' +
                    '</div>';


                document.getElementById(
                    "runButton"
                ).disabled = true;


                const formData = new FormData();

                formData.append(
                    "file_name",
                    uploadedFile
                );


                try {

                    const response = await fetch(
                        "/run-processor",
                        {
                            method: "POST",
                            body: formData
                        }
                    );


                    const result =
                        await response.json();


                    if (result.status === "COMPLETED") {

                        document.getElementById(
                            "processorStatus"
                        ).innerHTML =
                            '<div class="status success">' +

                            '<h3>✅ Processing Completed</h3>' +

                            '<pre>' +
                            JSON.stringify(
                                result,
                                null,
                                4
                            ) +
                            '</pre>' +

                            '</div>';

                    }
                    else {

                        document.getElementById(
                            "processorStatus"
                        ).innerHTML =
                            '<div class="status error">' +

                            '<h3>❌ Processing Failed</h3>' +

                            '<pre>' +
                            JSON.stringify(
                                result,
                                null,
                                4
                            ) +
                            '</pre>' +

                            '</div>';

                    }

                }
                catch (error) {

                    document.getElementById(
                        "processorStatus"
                    ).innerHTML =
                        '<div class="status error">' +

                        '<h3>❌ Processor Error</h3>' +

                        '<pre>' +
                        error +
                        '</pre>' +

                        '</div>';

                }
                finally {

                    document.getElementById(
                        "runButton"
                    ).disabled = false;

                }

            }

        </script>

    </body>

    </html>
    """


# --------------------------------
# Upload API
# --------------------------------

@app.post("/upload")
async def upload_file(file: UploadFile = File(...)):

    if not file.filename.lower().endswith(".edi"):

        return {
            "status": "ERROR",
            "message": "Only .edi files are allowed"
        }


    file_path = INBOUND_FOLDER / file.filename


    with file_path.open("wb") as buffer:

        shutil.copyfileobj(
            file.file,
            buffer
        )


    return {
        "status": "SUCCESS",
        "message": "EDI file uploaded successfully",
        "file": file.filename
    }


# --------------------------------
# Run Processor API
# --------------------------------

@app.post("/run-processor")
def run_processor(file_name: str = Form(...)):

    result = main(file_name)

    return result