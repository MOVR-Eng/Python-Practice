from fastapi import FastAPI

app = FastAPI()


@app.post("/orders")
def create_order(order: dict):

    print("\nOrder received by OMS:")
    print(order)

    return {
        "status": "SUCCESS",
        "message": "Order created successfully",
        "orderId": order["purchaseOrder"]
    }