from pathlib import Path
import json
import requests
import time


INBOUND_FOLDER = Path("inbound")
OUTPUT_FOLDER = Path("output")
ERROR_FOLDER = Path("error")
PROCESSED_FOLDER = Path("processed")

OMS_URL = "http://127.0.0.1:8000/orders"


def parse_edi(file_path):

    edi_content = file_path.read_text()

    segments = [
        segment.strip()
        for segment in edi_content.split("~")
        if segment.strip()
    ]

    return segments


def map_850_to_json(segments):

    purchase_order = None
    warehouse = None
    items = []

    for segment in segments:

        elements = segment.split("*")
        segment_id = elements[0]

        if segment_id == "BEG":
            purchase_order = elements[3]

        elif segment_id == "N1":

            if elements[1] == "ST":
                warehouse = elements[4]

        elif segment_id == "PO1":

            item = {
                "lineNumber": int(elements[1]),
                "quantity": int(elements[2]),
                "unit": elements[3],
                "price": float(elements[4]),
                "productId": elements[7]
            }

            items.append(item)

    return {
        "purchaseOrder": purchase_order,
        "warehouse": warehouse,
        "items": items
    }


def send_to_oms(order_data):

    max_retries = 3

    for attempt in range(1, max_retries + 1):

        print(
            f"\nSending order to OMS "
            f"(attempt {attempt}/{max_retries})..."
        )

        try:

            response = requests.post(
                OMS_URL,
                json=order_data,
                timeout=10
            )

            print(f"OMS HTTP Status: {response.status_code}")

            if response.status_code == 200:
                return response

            if response.status_code in [500, 502, 503, 504]:

                print("Temporary OMS error.")

                if attempt < max_retries:
                    print("Retrying in 2 seconds...")
                    time.sleep(2)
                    continue

            return response

        except requests.RequestException as error:

            print(f"Connection error: {error}")

            if attempt < max_retries:
                print("Retrying in 2 seconds...")
                time.sleep(2)

    return None


def get_control_numbers(segments):

    transaction_type = None
    transaction_control = None
    group_control = None

    for segment in segments:

        elements = segment.split("*")

        if elements[0] == "ST":

            transaction_type = elements[1]
            transaction_control = elements[2]

        elif elements[0] == "GS":

            group_control = elements[6]

    return (
        transaction_type,
        transaction_control,
        group_control
    )


def generate_997(
    transaction_type,
    transaction_control,
    group_control
):

    isa_control_number = "000000002"
    group_control_number = "2"
    acknowledgment_control = "0002"

    segments = [

        f"ISA*00*          *00*          *ZZ*XYZ_RETAIL      *ZZ*ABC_SUPPLIER    *261008*1000*U*00401*{isa_control_number}*0*P*>",

        f"GS*FA*XYZ_RETAIL*ABC_SUPPLIER*20261008*1000*{group_control_number}*X*004010",

        f"ST*997*{acknowledgment_control}",

        f"AK1*PO*{group_control}",

        f"AK2*{transaction_type}*{transaction_control}",

        "AK5*A",

        "AK9*A*1*1*1",

        f"SE*6*{acknowledgment_control}",

        f"GE*1*{group_control_number}",

        f"IEA*1*{isa_control_number}"
    ]

    return "~".join(segments) + "~"


def main(file_name:None):

    results = []

    file = INBOUND_FOLDER / file_name

    print(f"\nProcessing: {file}")

    # Check file exists

    if not file.exists():

        return {
            "status": "ERROR",
            "file": file_name,
            "message": "EDI file not found."
        }

    # Create folders if required

    OUTPUT_FOLDER.mkdir(exist_ok=True)
    ERROR_FOLDER.mkdir(exist_ok=True)
    PROCESSED_FOLDER.mkdir(exist_ok=True)

    try:

        # --------------------------------
        # 1. Read X12
        # --------------------------------

        segments = parse_edi(file)

        print("EDI file read successfully.")


        # --------------------------------
        # 2. X12 → JSON
        # --------------------------------

        order_json = map_850_to_json(segments)

        print("EDI mapped to JSON.")


        # --------------------------------
        # 3. Get control numbers
        # --------------------------------

        (
            transaction_type,
            transaction_control,
            group_control
        ) = get_control_numbers(segments)


        # --------------------------------
        # 4. Save JSON
        # --------------------------------

        output_file = (
            OUTPUT_FOLDER /
            f"{file.stem}.json"
        )

        output_file.write_text(
            json.dumps(
                order_json,
                indent=4
            )
        )

        print(f"JSON created: {output_file}")


        # --------------------------------
        # 5. Send to OMS
        # --------------------------------

        response = send_to_oms(order_json)


        # --------------------------------
        # 6. Check OMS response
        # --------------------------------

        if response and response.status_code == 200:

            oms_response = response.json()

            print("OMS processing successful!")

            print("OMS response:")
            print(oms_response)


            # --------------------------------
            # 7. Generate 997
            # --------------------------------

            acknowledgment = generate_997(
                transaction_type,
                transaction_control,
                group_control
            )

            ack_file = (
                OUTPUT_FOLDER /
                f"{file.stem}_997.edi"
            )

            ack_file.write_text(
                acknowledgment
            )

            print(f"997 created: {ack_file}")


            # --------------------------------
            # 8. Move EDI to processed
            # --------------------------------

            destination = (
                PROCESSED_FOLDER /
                file.name
            )

            file.rename(destination)

            print(
                f"EDI moved to: {destination}"
            )


            results.append({

                "status": "SUCCESS",

                "file": file.name,

                "json_file": output_file.name,

                "ack_file": ack_file.name,

                "oms_response": oms_response
            })


        else:

            print("OMS processing failed!")


            # --------------------------------
            # Move EDI to error
            # --------------------------------

            destination = (
                ERROR_FOLDER /
                file.name
            )

            file.rename(destination)

            print(
                f"EDI moved to: {destination}"
            )


            results.append({

                "status": "ERROR",

                "file": file.name,

                "message": "OMS processing failed."
            })


    except Exception as error:

        print(
            f"Unexpected error: {error}"
        )


        # --------------------------------
        # Move EDI to error
        # --------------------------------

        destination = (
            ERROR_FOLDER /
            file.name
        )

        if file.exists():

            file.rename(destination)

            print(
                f"EDI moved to: {destination}"
            )


        results.append({

            "status": "ERROR",

            "file": file.name,

            "message": str(error)
        })


    return {

        "status": "COMPLETED",

        "results": results
    }


# --------------------------------
# Direct Python execution
# --------------------------------

if __name__ == "__main__":

    main(file_name)